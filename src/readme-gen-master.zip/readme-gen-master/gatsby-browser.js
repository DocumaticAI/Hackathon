import './src/styles/tailwind.css';
require('prismjs/themes/prism-okaidia.css');
